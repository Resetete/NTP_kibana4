echo "removing unwanted dependencies"
rm -rf ./public/bower_components/angular